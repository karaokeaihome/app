#!/system/bin/sh
# Lamborghini: gioi han CPU chong qua nhiet (goi tu ch_start.sh)
(
CPU=/sys/devices/system/cpu/cpu0/cpufreq
PCM=/proc/asound/card0/pcm0p/sub0/status
TRIG=/data/local/kboost
LOW=600000
HIGH=1200000
MAXB=45
setf() {
  echo userspace > $CPU/scaling_governor
  echo $1 > $CPU/scaling_max_freq
  echo $1 > $CPU/scaling_setspeed
}
setf $LOW
echo 0 > /sys/devices/system/cpu/cpu3/online
echo 0 > /sys/devices/system/cpu/cpu2/online
if [ -f /data/local/kfw.sh ]
then
  sh /data/local/kfw.sh >/dev/null 2>&1 &
fi
boost=0
ui=0
# file the app writes "1" into when a remote key is pressed (app cannot create files in /data/local itself)
[ -f /data/local/kui ] || touch /data/local/kui
chmod 666 /data/local/kui
cur=$LOW
lastpid=""
n=0
while true
do
  # DNS: vendor DHCP hands out 114.114.114.114 (slow from VN); use Google + Cloudflare
  if [ $(($n % 30)) -eq 0 ] && [ "`getprop net.dns1`" != "8.8.8.8" ]
  then
    ndc resolver setifdns wlan0 '' 8.8.8.8 1.1.1.1 >/dev/null 2>&1
    ndc resolver setifdns eth0 '' 8.8.8.8 1.1.1.1 >/dev/null 2>&1
    ndc resolver flushif wlan0 >/dev/null 2>&1
    setprop net.dns1 8.8.8.8
    setprop net.dns2 1.1.1.1
  fi
  # vendor setprop.sh clears enabled_accessibility_services at boot -> re-enable karaoke Mic service
  if [ $(($n % 120)) -eq 5 ]
  then
    acc=`settings get secure enabled_accessibility_services`
    case "$acc" in
      *nhaminh*) ;;
      *) settings put secure enabled_accessibility_services vn.nhaminh.karaoke/vn.nhaminh.karaoke.VoiceAccessibilityService
         settings put secure accessibility_enabled 1 ;;
    esac
  fi
  n=$(($n+1))
  # iFlytek BT auto-pair: pause BLE scanning while a Bluetooth input device (Bus=0005) is connected, resume when none
  if [ $(($n % 10)) -eq 3 ]
  then
    bt=`grep -c 'Bus=0005' /proc/bus/input/devices 2>/dev/null`
    ifl=`busybox pidof com.iflytek.bt.auto`
    if [ "$bt" != "0" ]
    then
      if [ -n "$ifl" ]
      then
        am force-stop com.iflytek.bt.auto >/dev/null 2>&1
      fi
    else
      if [ -z "$ifl" ]
      then
        am startservice -n com.iflytek.bt.auto/.AutoParingService >/dev/null 2>&1
      fi
    fi
  fi
  play=`grep -c RUNNING $PCM 2>/dev/null`
  app=`busybox pidof org.smarttube.stable`
  # keep SmartTube warm in background
  if [ -n "$app" ]
  then
    echo 1 > /proc/$app/oom_adj 2>/dev/null
  fi
  start=0
  if [ -f $TRIG ]
  then
    rm -f $TRIG
    start=1
  fi
  if [ -n "$app" ] && [ "$app" != "$lastpid" ]
  then
    start=1
  fi
  lastpid="$app"
  if [ $start -eq 1 ]
  then
    boost=1
  fi
  if [ -s /data/local/kui ]
  then
    : > /data/local/kui
    ui=6
  fi
  if [ $boost -gt 0 ]
  then
    if [ "$play" != "0" ] || [ $boost -gt $MAXB ]
    then
      boost=0
    else
      boost=$(($boost+1))
    fi
  fi
  if [ $boost -gt 0 ] || [ $ui -gt 0 ]
  then
    want=$HIGH
  else
    want=$LOW
  fi
  g=`cat $CPU/scaling_governor`
  if [ "$want" != "$cur" ] || [ "$g" != "userspace" ]
  then
    setf $want
    cur=$want
  fi
  echo 0 > /sys/devices/system/cpu/cpu3/online 2>/dev/null
  echo 0 > /sys/devices/system/cpu/cpu2/online 2>/dev/null
  if [ $ui -gt 0 ]
  then
    ui=$(($ui-1))
  fi
  sleep 1
done
) &
