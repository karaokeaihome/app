#!/system/bin/sh
# CHẶN ADB QUA MẠNG sau khi nâng cấp loa (rà soát bảo mật 2026-11-23).
# Cổng 30010 mở cho cả mạng LAN = ai cùng Wi-Fi cũng cài được app lạ / đọc app của mình.
# Chỉ cho 127.0.0.1 (KeyDaemon, RemoteKho, RemoteKeys của app dùng ADB nội bộ).
# Mở 30 phút khi khách bấm Cài đặt → "Mở nâng cấp qua mạng (30 phút)" (app ghi /data/local/kadbopen).
# Chạy bằng ROOT: gọi một lần lúc khởi động trong script hệ thống (hisbootcpuset), sau đó nó tự lặp mỗi 20 giây.
# Tắt khẩn cấp: xoá /data/local/kfw.on rồi khởi động lại loa.
PORT=30010
OPEN=/data/local/kadbopen
[ -f /data/local/kfw.on ] || exit 0
[ -f $OPEN ] || { echo 0 > $OPEN; }
chmod 666 $OPEN
block() { iptables -C INPUT -p tcp --dport $PORT ! -s 127.0.0.1 -j DROP 2>/dev/null || iptables -I INPUT -p tcp --dport $PORT ! -s 127.0.0.1 -j DROP; }
unblock() { while iptables -D INPUT -p tcp --dport $PORT ! -s 127.0.0.1 -j DROP 2>/dev/null; do :; done; }
while true; do
  [ -f /data/local/kfw.on ] || { unblock; exit 0; }
  T=$(cat $OPEN 2>/dev/null); T=${T%???}   # mili giây → giây
  NOW=$(date +%s)
  if [ -n "$T" ] && [ "$T" -gt 0 ] 2>/dev/null && [ $((NOW - T)) -lt 1800 ] && [ $((NOW - T)) -gt -60 ]; then unblock; else block; fi
  sleep 20
done
