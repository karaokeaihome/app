#!/system/bin/sh
# Script cài đặt chạy TRÊN LOA (adb shell, quyền root) sau khi app đã được cài.
# Mọi bước đều chạy lại được nhiều lần (đã đúng thì bỏ qua).
# Dòng bắt đầu bằng @STEP / @FAIL / @DONE được app điện thoại đọc để hiện tiến độ.
MODEL="$1"
P=/data/local/tmp/cailoa
F=$P/files
step() { echo "@STEP $*"; }
fail() { echo "@FAIL $*"; exit 1; }
match() { [ "$1" = "*" ] || [ "$1" = "$MODEL" ]; }

# 1. Tắt app Trung Quốc + launcher gốc (chỉ sau khi Karaoke đã cài, vì nó là màn hình chính mới)
if [ -f $F/disable.txt ]; then
  step "Tắt app Trung Quốc"
  ls /data/data/vn.nhaminh.karaoke >/dev/null 2>&1 || fail "Chưa có app Karaoke, không tắt launcher gốc"
  while read -r pkg; do
    case "$pkg" in ""|\#*) continue;; esac
    pm disable "$pkg" >/dev/null 2>&1
  done < $F/disable.txt
fi

# 1b. Gỡ app không cài sẵn nữa (uninstall.txt)
if [ -f $F/uninstall.txt ]; then
  step "Gỡ app không cần"
  while read -r pkg; do
    case "$pkg" in ""|\#*) continue;; esac
    [ -d /data/data/$pkg ] && pm uninstall "$pkg" >/dev/null 2>&1
  done < $F/uninstall.txt
fi

# 2. Cài đặt hệ thống (settings.txt: "namespace key value")
if [ -f $F/settings.txt ]; then
  step "Cài đặt hệ thống"
  while read -r ns key val; do
    case "$ns" in ""|\#*) continue;; esac
    settings put "$ns" "$key" "$val"
  done < $F/settings.txt
fi

# 3. Nút Mic tìm bằng giọng nói ở mọi màn hình (dịch vụ trợ năng của app Karaoke)
step "Bật nút Mic giọng nói"
SVC=vn.nhaminh.karaoke/vn.nhaminh.karaoke.VoiceAccessibilityService
CUR=$(settings get secure enabled_accessibility_services)
case "$CUR" in
  *"$SVC"*) ;;
  ""|null) settings put secure enabled_accessibility_services "$SVC" ;;
  *) settings put secure enabled_accessibility_services "$CUR:$SVC" ;;
esac
settings put secure accessibility_enabled 1

# 3b. SmartTube: lần đầu mở trên Dalvik phải giải nén MultiDex rất lâu (dễ báo "không phản hồi") -> mở trước 1 lần
ST=org.smarttube.stable
if [ -d /data/data/$ST ] && ! ls /data/data/$ST/code_cache/secondary-dexes/ 2>/dev/null | grep -q classes3.dex; then
  step "Mở SmartTube lần đầu (1-3 phút)"
  monkey -p $ST -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1
  i=0
  while [ $i -lt 18 ]; do
    sleep 10
    ls /data/data/$ST/code_cache/secondary-dexes/ 2>/dev/null | grep -q classes3.dex && break
    i=$((i+1))
  done
  sleep 15
  am force-stop $ST >/dev/null 2>&1
  am start -n vn.nhaminh.karaoke/.HomeActivity >/dev/null 2>&1
fi

# 4. File dữ liệu (data.txt: "model|nguồn|đích|quyền|gói-sở-hữu")
#    vd SmartTube 360p: *|smarttube/video_player_data|/data/data/org.smarttube.stable/files/app_prefs/video_player_data|600|org.smarttube.stable
if [ -f $F/data.txt ]; then
  step "Chép cấu hình app"
  while IFS='|' read -r m src dst mode owner; do
    case "$m" in ""|\#*) continue;; esac
    match "$m" || continue
    [ -f "$F/$src" ] || fail "Gói thiếu file $src"
    if [ -n "$owner" ]; then
      [ -d /data/data/$owner ] || { echo "bo qua $dst (chua co app $owner)"; continue; }
      am force-stop "$owner" >/dev/null 2>&1
    fi
    mkdir -p "${dst%/*}"
    cat "$F/$src" > "$dst" || fail "Không ghi được $dst"
    chmod "${mode:-644}" "$dst"
    if [ -n "$owner" ]; then
      set -- $(ls -ld /data/data/$owner)
      chown "$2:$3" "${dst%/*}" "$dst"
    fi
  done < $F/data.txt
fi

# 5. File hệ thống (system.txt: "model|nguồn|đích|quyền"): font, script chống nóng…
if [ -f $F/system.txt ]; then
  step "Ghi file hệ thống (chống nóng, font)"
  RW=0
  while IFS='|' read -r m src dst mode; do
    case "$m" in ""|\#*) continue;; esac
    match "$m" || continue
    [ -f "$F/$src" ] || fail "Gói thiếu file $src"
    if cmp "$F/$src" "$dst" >/dev/null 2>&1; then echo "da dung: $dst"; continue; fi
    if [ $RW = 0 ]; then mount -o remount,rw /system || fail "Không mở ghi được /system"; RW=1; fi
    cat "$F/$src" > "$dst.cailoa" && chmod "${mode:-644}" "$dst.cailoa" && mv "$dst.cailoa" "$dst" || fail "Không ghi được $dst"
    cmp "$F/$src" "$dst" >/dev/null 2>&1 || fail "Ghi $dst bị sai"
    echo "da ghi: $dst"
  done < $F/system.txt
  [ $RW = 1 ] && { sync; mount -o remount,ro /system; }
  # Áp dụng chống nóng ngay (không đợi khởi động lại): 600 MHz, tắt nhân 3 và 4
  if grep -q "^LOW=600000" $F/cpu/hisbootcpuset.sh 2>/dev/null; then
    C=/sys/devices/system/cpu
    echo userspace > $C/cpu0/cpufreq/scaling_governor 2>/dev/null
    echo 600000 > $C/cpu0/cpufreq/scaling_max_freq 2>/dev/null
    echo 600000 > $C/cpu0/cpufreq/scaling_setspeed 2>/dev/null
    echo 0 > $C/cpu3/online 2>/dev/null; echo 0 > $C/cpu2/online 2>/dev/null
  fi
fi

# 6. Lệnh riêng cho từng đời loa (post-<model>.sh hoặc post.sh), nếu gói có
for s in "$F/post.sh" "$F/post-$MODEL.sh"; do
  if [ -f "$s" ]; then step "Bước riêng: ${s##*/}"; sh "$s" "$MODEL" || fail "${s##*/} lỗi"; fi
done

# 7. Ẩn mục "Tùy chọn nhà phát triển" khỏi Cài đặt (Gỡ lỗi USB vẫn bật; script khởi động tự mở lại cổng 30010)
DX=/data/data/com.android.settings/shared_prefs/development.xml
if [ -f $DX ] && grep -q 'name="show" value="true"' $DX; then
  step "Ẩn Tùy chọn nhà phát triển"
  am force-stop com.android.settings >/dev/null 2>&1
  sed 's/name="show" value="true"/name="show" value="false"/' $DX > $DX.tmp && cat $DX.tmp > $DX && rm -f $DX.tmp
fi

# 8. Chặn máy lạ trong Wi-Fi vào ADB (người dùng chọn 2026-11-23). Chỉ bật khi app Karaoke đủ mới (vc >= 82) để
#    khách còn nút Cài đặt -> "Mở nâng cấp qua mạng (30 phút)". Có hiệu lực từ lần khởi động sau.
VC=$(dumpsys package vn.nhaminh.karaoke | grep versionCode | head -1 | sed 's/.*versionCode=\([0-9]*\).*/\1/')
if [ -f /data/local/kfw.sh ] && [ -n "$VC" ] && [ "$VC" -ge 82 ] 2>/dev/null; then
  step "Bật chặn ADB từ máy lạ"
  echo 1 > /data/local/kfw.on
fi

sync
echo "@DONE"
